<?php 
    //tangkap request class_buah
    require_once "class_buah.php";

    // crate instan objek fruit : $apple and $banana
    $apple = new fruit();
    $banana = new fruit();

    // call member class
    $apple->set_name("Apel");
    $apple->set_color("Merah");
    $banana->set_name("Pisang");
    $banana->set_color("Kuning");

    echo 'Nama Buah : '.$apple->get_name().',Warnanya : '.$apple->get_color();
    echo '<br>';
    echo 'Nama Buah : '.$banana->get_name().',Warnanya : '.$banana->get_color();

?>