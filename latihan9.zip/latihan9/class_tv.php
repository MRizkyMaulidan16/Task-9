<?php
class tv{
    //properties atau variable
    public $name;
    public $size;
    
    function set_name($name){
        $this->name = $name;
    }

    function set_size($size){
        $this->size = $size;
    }

    function get_name(){
        return $this->name;
    }

    function get_size(){
        return $this->size;
    }
}
?>