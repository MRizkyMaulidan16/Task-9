<?php 
    require_once "class_tv.php";

    $toshiba = new tv();
    $smart = new tv();
    $samsung = new tv();
    $lg = new tv();

    $toshiba->set_name("Toshiba");
    $toshiba->set_size("Besar");
    $smart->set_name("Smart");
    $smart->set_size("Sedang");
    $samsung->set_name("Samsung");
    $samsung->set_size("Kecil");
    $lg->set_name("LG");
    $lg->set_size("Besar");

    echo 'Nama TV: '.$toshiba->get_name().', Ukuran: '.$toshiba->get_size();
    echo '<br>';
    echo 'Nama TV : '.$smart->get_name().', Ukuran : '.$smart->get_size();
    echo '<br>';
    echo 'Nama TV : '.$samsung->get_name().', Ukuran : '.$samsung->get_size();
    echo '<br>';
    echo 'Nama TV : '.$lg->get_name().', Ukuran : '.$lg->get_size();

?>